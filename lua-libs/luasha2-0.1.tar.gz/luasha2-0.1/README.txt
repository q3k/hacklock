Based on Cosmin Apreutesei's sha2 library. See LICENSE.txt.
